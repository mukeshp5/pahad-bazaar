# Pahad Bazaar — runnable marketplace starter

A Next.js + Supabase marketplace starter for local producers across Uttarakhand. It includes:
- Customer storefront, product catalogue, product detail, cart and order history
- Supabase email/password authentication
- Seller application and product listing dashboard
- Admin seller/product approval screen
- Razorpay order creation, signature verification and webhook endpoint
- PWA manifest and service worker
- PostgreSQL schema with Row Level Security policies

> This is a launchable foundation, not a finished audited commerce platform. Before taking real orders, complete the production checklist below. Demo content, prices, images, shipping and commission are not live/verified.

## 1. Requirements
- Node.js 20+
- A Supabase project
- Razorpay account (start with test mode)
- GitHub account and Vercel account for deployment

## 2. Install
```bash
npm install
cp .env.example .env.local
npm run dev
```
Open http://localhost:3000.

## 3. Configure Supabase
1. Create a project at https://supabase.com.
2. Open SQL Editor and run `supabase/schema.sql`.
3. Copy Project URL, anon key and service-role key into `.env.local`.
4. In Authentication > URL Configuration, set Site URL to your local URL and add your deployed URL to Redirect URLs.
5. Enable email/password authentication.
6. In Authentication settings, configure email confirmation and SMTP before public launch.
7. Create your first admin user through the signup page.
8. In Supabase SQL Editor, promote that user:
```sql
update public.profiles
set role='admin', seller_status='approved'
where id = 'YOUR_AUTH_USER_UUID';
```
Never allow users to self-assign the admin role. Keep service-role credentials server-only.

## 4. Configure Razorpay (test mode)
Add:
- `RAZORPAY_KEY_ID`
- `RAZORPAY_KEY_SECRET`
- `RAZORPAY_WEBHOOK_SECRET`
- `NEXT_PUBLIC_RAZORPAY_KEY_ID` (the public key ID only)

In Razorpay dashboard, create a webhook pointing to:
`https://YOUR_DOMAIN/api/checkout/webhook`
Subscribe to `payment.captured` and `payment.failed`.
Use test keys until end-to-end tests pass.

## 5. Run locally
```bash
npm run dev
```
Flow:
1. Create a customer account at `/account`.
2. Register as seller at `/seller`.
3. Admin approves seller at `/admin`.
4. Seller signs in and adds products at `/seller/dashboard`.
5. Admin approves product.
6. Customer adds product to cart and checks out.

## 6. Deploy to Vercel
1. Push this project to a private GitHub repository.
2. Import the repository into Vercel.
3. Add all `.env.local` values in Vercel Project Settings > Environment Variables.
4. Add `NEXT_PUBLIC_RAZORPAY_KEY_ID` with the public test key ID.
5. Set `NEXT_PUBLIC_SITE_URL` to your production HTTPS domain.
6. Deploy.
7. Add production domain to Supabase Auth redirect URLs.
8. Configure Razorpay webhook to the production URL.
9. Test payment, webhook, failed payment and order visibility before switching to live keys.

## 7. PWA installation
The manifest and service worker are included. Serve the site over HTTPS (localhost is also allowed for development), then use the browser's "Install app" / "Add to Home Screen" option.
Basic 192x192 and 512x512 PNG icons are included; replace them with your final approved brand artwork before release. Offline caching is only a basic app-shell fallback; checkout and account features require connectivity.

## 8. Shipping architecture
The starter stores shipping address and tracking fields on `orders`, but checkout currently uses `shipping_paise = 0` and does not create courier labels. Do not launch paid orders until shipping is implemented.

Recommended production flow:
1. Collect and validate customer's delivery address and pincode.
2. Get a live serviceability/rate quote from Shiprocket (or another courier aggregator).
3. Store shipping quote and freeze it into the order.
4. After payment capture, create shipment and label via server-side API.
5. Save courier, AWB/tracking number and tracking URL.
6. Process courier webhooks to update shipment state.
7. Provide a manual fallback for remote pin codes and restricted routes.

Do not put courier API credentials in browser code.

## 9. Marketplace commission and payouts
Schema includes `seller_payouts` and order-item commission fields. This starter does not automatically transfer money to sellers. Initially, reconcile captured orders and pay sellers manually on a weekly/fortnightly cycle after delivery and return window. Publish the commission rate, shipping deduction rules, return policy and settlement schedule.
Before automating split payouts, evaluate Razorpay Route / marketplace onboarding, KYC, settlement eligibility and applicable RBI/payment aggregator requirements with Razorpay and a qualified CA/legal adviser. Do not collect customer money into an informal personal account for onward distribution.

## 10. Important production work before launch
- Fix/complete checkout address capture and shipping quote integration.
- Add atomic stock reservation/decrement to prevent overselling.
- Add idempotent payment webhook processing and refund handling.
- Add seller KYC/bank details through a compliant provider; never store raw sensitive bank credentials.
- Add image upload using Supabase Storage with file type/size limits.
- Add seller order fulfilment view and order status updates.
- Add admin order/refund/dispute and commission reports.
- Add product moderation, prohibited-items policy and seller agreements.
- Add GST invoice/tax handling, FSSAI compliance for applicable food products, Legal Metrology declarations/packaging where applicable, privacy policy, terms and consumer grievance contact.
- Add rate limiting, bot protection, monitoring, backups and security review.
- Test on low-bandwidth mobile connections and Android Chrome.

## 11. Important note about the current starter
The first version provides working page flows and a basic server-side Razorpay integration. It is not yet safe to accept live payments because shipping charge is a placeholder, inventory reservation and full refunds are not implemented, and seller payouts are manual. Use test mode only until these are completed and independently reviewed.
