-- Pahad Bazaar marketplace schema for Supabase (PostgreSQL)
create extension if not exists pgcrypto;

create type public.user_role as enum ('customer','seller','admin');
create type public.seller_status as enum ('pending','approved','rejected','suspended');
create type public.product_status as enum ('draft','pending','active','rejected','archived');
create type public.order_status as enum ('payment_pending','paid','processing','shipped','delivered','cancelled','payment_failed','refunded');

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  role public.user_role not null default 'customer',
  display_name text,
  phone text,
  district text,
  village text,
  seller_type text,
  about text,
  seller_status public.seller_status not null default 'pending',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.products (
  id uuid primary key default gen_random_uuid(),
  seller_id uuid not null references public.profiles(id) on delete cascade,
  name text not null,
  slug text not null unique,
  description text not null,
  category text not null,
  price_paise integer not null check(price_paise > 0),
  stock_quantity integer not null default 0 check(stock_quantity >= 0),
  images text[] not null default '{}',
  origin_village text,
  origin_district text,
  status public.product_status not null default 'pending',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.orders (
  id uuid primary key default gen_random_uuid(),
  order_number text not null unique default ('PB-' || upper(substr(replace(gen_random_uuid()::text,'-',''),1,10))),
  customer_id uuid not null references public.profiles(id),
  status public.order_status not null default 'payment_pending',
  subtotal_paise integer not null check(subtotal_paise >= 0),
  shipping_paise integer not null default 0 check(shipping_paise >= 0),
  total_paise integer not null check(total_paise >= 0),
  currency text not null default 'INR',
  razorpay_order_id text unique,
  razorpay_payment_id text,
  paid_at timestamptz,
  shipping_name text,
  shipping_phone text,
  shipping_address jsonb,
  courier_name text,
  tracking_number text,
  tracking_url text,
  created_at timestamptz not null default now()
);

create table public.order_items (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.orders(id) on delete cascade,
  product_id uuid references public.products(id),
  seller_id uuid not null references public.profiles(id),
  product_name text not null,
  unit_price_paise integer not null,
  quantity integer not null check(quantity > 0),
  line_total_paise integer not null,
  commission_paise integer,
  seller_payout_paise integer,
  created_at timestamptz not null default now()
);

create table public.seller_payouts (
  id uuid primary key default gen_random_uuid(),
  seller_id uuid not null references public.profiles(id),
  order_item_id uuid not null references public.order_items(id),
  gross_paise integer not null,
  commission_paise integer not null,
  net_paise integer not null,
  status text not null default 'pending' check(status in ('pending','approved','paid','held')),
  payout_reference text,
  paid_at timestamptz,
  created_at timestamptz not null default now()
);

create table public.addresses (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  full_name text not null,
  phone text not null,
  line1 text not null,
  line2 text,
  village_city text not null,
  district text not null,
  state text not null default 'Uttarakhand',
  pincode text not null,
  is_default boolean not null default false,
  created_at timestamptz not null default now()
);

create table public.reviews (
  id uuid primary key default gen_random_uuid(),
  product_id uuid not null references public.products(id) on delete cascade,
  customer_id uuid not null references public.profiles(id),
  order_id uuid not null references public.orders(id),
  rating integer not null check(rating between 1 and 5),
  review text,
  created_at timestamptz not null default now(),
  unique(product_id,customer_id,order_id)
);

create table public.audit_logs (
  id uuid primary key default gen_random_uuid(),
  actor_id uuid references public.profiles(id),
  action text not null,
  entity_type text not null,
  entity_id uuid,
  details jsonb not null default '{}',
  created_at timestamptz not null default now()
);

-- Automatically create a customer profile after signup.
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path=public as $$
begin
  insert into public.profiles(id,display_name,role)
  values(new.id,coalesce(new.raw_user_meta_data->>'display_name','New customer'),'customer')
  on conflict(id) do nothing;
  return new;
end; $$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
for each row execute procedure public.handle_new_user();

-- Seller registration: allow users to request seller role, but only admin approves seller_status.
create or replace function public.request_seller_role()
returns trigger language plpgsql security definer set search_path=public as $$
begin
  -- A signed-in user may request seller status, but cannot approve themselves or become admin.
  if auth.uid() is not null and auth.uid() = old.id
     and not public.is_admin() then
    if new.role = 'admin' then raise exception 'Cannot self-assign admin'; end if;
    if old.role = 'customer' and new.role = 'seller' then
      new.seller_status := 'pending';
    else
      new.seller_status := old.seller_status;
      if new.role <> old.role then raise exception 'Role change not permitted'; end if;
    end if;
  end if;
  return new;
end; $$;
drop trigger if exists protect_profile_role on public.profiles;
create trigger protect_profile_role before update on public.profiles
for each row execute procedure public.request_seller_role();

alter table public.profiles enable row level security;
alter table public.products enable row level security;
alter table public.orders enable row level security;
alter table public.order_items enable row level security;
alter table public.addresses enable row level security;
alter table public.reviews enable row level security;
alter table public.seller_payouts enable row level security;
alter table public.audit_logs enable row level security;

-- SECURITY DEFINER helper avoids recursive RLS when policies check administrator status.
create or replace function public.is_admin()
returns boolean language sql stable security definer set search_path=public as $$
  select exists(select 1 from public.profiles where id=auth.uid() and role='admin');
$$;
grant execute on function public.is_admin() to authenticated;

-- Profile access
create policy "profiles are readable by owner or admin" on public.profiles for select using (auth.uid()=id or public.is_admin());
create policy "users update own profile" on public.profiles for update using(auth.uid()=id) with check(auth.uid()=id and role <> 'admin');
create policy "users insert own profile" on public.profiles for insert with check(auth.uid()=id and role='customer');

-- Public can see active products. Sellers can see/manage their own listings.
create policy "active products public read" on public.products for select using(status='active' or seller_id=auth.uid() or public.is_admin());
create policy "approved sellers can create products" on public.products for insert with check(seller_id=auth.uid() and exists(select 1 from public.profiles p where p.id=auth.uid() and p.role='seller' and p.seller_status='approved'));
create policy "seller update own products" on public.products for update using(seller_id=auth.uid() or public.is_admin()) with check(seller_id=auth.uid() or public.is_admin());

-- Customer sees own orders. Sellers see orders containing their items.
create policy "customer or seller reads relevant orders" on public.orders for select using(customer_id=auth.uid() or public.is_admin() or exists(select 1 from public.order_items oi where oi.order_id=id and oi.seller_id=auth.uid()));
create policy "customer reads own order items" on public.order_items for select using(exists(select 1 from public.orders o where o.id=order_id and o.customer_id=auth.uid()) or seller_id=auth.uid() or public.is_admin());

-- Addresses
create policy "user manages own addresses" on public.addresses for all using(user_id=auth.uid()) with check(user_id=auth.uid());

-- Reviews
create policy "reviews are public" on public.reviews for select using(true);
create policy "customer creates own review" on public.reviews for insert with check(customer_id=auth.uid() and exists(select 1 from public.orders o where o.id=order_id and o.customer_id=auth.uid() and o.status='delivered'));

-- Seller payouts visible only to seller/admin
create policy "seller sees own payouts" on public.seller_payouts for select using(seller_id=auth.uid() or public.is_admin());

-- Admin-only audit logs
create policy "admin reads audit logs" on public.audit_logs for select using(public.is_admin());

create index products_status_category_idx on public.products(status,category);
create index products_seller_idx on public.products(seller_id);
create index orders_customer_idx on public.orders(customer_id,created_at desc);
create index order_items_seller_idx on public.order_items(seller_id);
