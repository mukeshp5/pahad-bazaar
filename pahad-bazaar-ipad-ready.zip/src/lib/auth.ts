import { createClient } from "@/lib/supabase/server";

export async function currentUser() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  return { supabase, user };
}

export async function requireRole(roles: string[]) {
  const { supabase, user } = await currentUser();
  if (!user) return { supabase, user: null, profile: null, error: "Sign in required" };
  const { data: profile } = await supabase.from("profiles").select("*").eq("id", user.id).single();
  if (!profile || !roles.includes(profile.role)) {
    return { supabase, user, profile, error: "You do not have permission to access this area" };
  }
  return { supabase, user, profile, error: null };
}
