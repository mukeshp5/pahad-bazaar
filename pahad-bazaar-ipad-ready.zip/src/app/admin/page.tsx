import { requireRole } from "@/lib/auth";
import { redirect } from "next/navigation";

export default async function AdminPage(){
 const {supabase,user,profile,error}=await requireRole(["admin"]);
 if(!user) redirect("/account");
 if(error) return <main className="container" style={{padding:40}}><h1>Admin access</h1><p>{error}</p><p>Ask the platform owner to assign your profile role to admin in Supabase.</p></main>;
 const [{data:sellers},{data:products},{data:orders}] = await Promise.all([
  supabase.from("profiles").select("id,display_name,district,seller_status,created_at").eq("role","seller").order("created_at",{ascending:false}),
  supabase.from("products").select("id,name,status,price_paise,created_at").order("created_at",{ascending:false}).limit(100),
  supabase.from("orders").select("id,order_number,status,total_paise,created_at").order("created_at",{ascending:false}).limit(100)
 ]);
 return <main className="container" style={{padding:"40px 0"}}><h1 className="brand">Marketplace admin</h1><p className="muted">Review sellers, products and orders.</p><h2>Seller applications</h2>{sellers?.map(s=><div className="card" key={s.id} style={{padding:14,marginBottom:9,display:"flex",justifyContent:"space-between",gap:12,alignItems:"center"}}><div><strong>{s.display_name}</strong><div className="muted">{s.district} · {s.seller_status}</div></div><form action="/api/admin/seller-status" method="post"><input type="hidden" name="sellerId" value={s.id}/><button className="btn" name="status" value="approved">Approve</button><button className="btn secondary" name="status" value="rejected" style={{marginLeft:6}}>Reject</button></form></div>)}<h2 style={{marginTop:32}}>Products pending review</h2>{products?.filter(p=>p.status==="pending").map(p=><div className="card" key={p.id} style={{padding:14,marginBottom:9}}><strong>{p.name}</strong><form action="/api/admin/product-status" method="post" style={{display:"flex",gap:8,marginTop:8}}><input type="hidden" name="productId" value={p.id}/><button className="btn" name="status" value="active">Approve</button><button className="btn secondary" name="status" value="rejected">Reject</button></form></div>)}<h2 style={{marginTop:32}}>Recent orders</h2>{orders?.map(o=><div className="card" key={o.id} style={{padding:12,marginBottom:8}}><strong>{o.order_number}</strong> · ₹{(o.total_paise/100).toFixed(0)} · {o.status}</div>)}</main>;
}
