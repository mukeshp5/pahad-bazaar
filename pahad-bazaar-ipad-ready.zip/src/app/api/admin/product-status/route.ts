import { NextResponse } from "next/server";
import { requireRole } from "@/lib/auth";
import { adminDb } from "@/lib/supabase/admin";

export async function POST(req:Request){
 const {user,error}=await requireRole(["admin"]);
 if(!user||error)return NextResponse.json({error:"Forbidden"},{status:403});
 const form=await req.formData();
 const productId=String(form.get("productId"));
 const status=String(form.get("status"));
 if(!["active","rejected"].includes(status))return NextResponse.json({error:"Invalid status"},{status:400});
 const {error:updateError}=await adminDb.from("products").update({status}).eq("id",productId);
 if(updateError)return NextResponse.json({error:updateError.message},{status:400});
 return NextResponse.redirect(new URL("/admin",req.url));
}
