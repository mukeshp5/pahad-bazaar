import { NextResponse } from "next/server";
import crypto from "crypto";
import { adminDb } from "@/lib/supabase/admin";

export async function POST(req:Request){
 const raw=await req.text();
 const signature=req.headers.get("x-razorpay-signature")||"";
 const expected=crypto.createHmac("sha256",process.env.RAZORPAY_WEBHOOK_SECRET!).update(raw).digest("hex");
 if(!signature||signature!==expected)return NextResponse.json({error:"Invalid webhook signature"},{status:400});
 const event=JSON.parse(raw);
 if(event.event==="payment.captured"){
  const payment=event.payload.payment.entity;
  const rpOrderId=payment.order_id;
  await adminDb.from("orders").update({status:"paid",razorpay_payment_id:payment.id,paid_at:new Date().toISOString()}).eq("razorpay_order_id",rpOrderId);
 }
 if(event.event==="payment.failed"){
  const payment=event.payload.payment.entity;
  await adminDb.from("orders").update({status:"payment_failed"}).eq("razorpay_order_id",payment.order_id).neq("status","paid");
 }
 return NextResponse.json({received:true});
}
