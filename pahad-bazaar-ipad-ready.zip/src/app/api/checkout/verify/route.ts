import { NextResponse } from "next/server";
import crypto from "crypto";
import { z } from "zod";
import { currentUser } from "@/lib/auth";
import { adminDb } from "@/lib/supabase/admin";

const schema=z.object({razorpay_order_id:z.string(),razorpay_payment_id:z.string(),razorpay_signature:z.string(),orderId:z.string().uuid()});
export async function POST(req:Request){
 try{
  const {user}=await currentUser();if(!user)return NextResponse.json({error:"Sign in required"},{status:401});
  const b=schema.parse(await req.json());
  const {data:order}=await adminDb.from("orders").select("*").eq("id",b.orderId).eq("customer_id",user.id).single();
  if(!order||order.razorpay_order_id!==b.razorpay_order_id)return NextResponse.json({error:"Order mismatch"},{status:400});
  const expected=crypto.createHmac("sha256",process.env.RAZORPAY_KEY_SECRET!).update(`${b.razorpay_order_id}|${b.razorpay_payment_id}`).digest("hex");
  if(expected!==b.razorpay_signature)return NextResponse.json({error:"Invalid payment signature"},{status:400});
  await adminDb.from("orders").update({status:"paid",razorpay_payment_id:b.razorpay_payment_id,paid_at:new Date().toISOString()}).eq("id",order.id);
  return NextResponse.json({ok:true});
 }catch(e:any){return NextResponse.json({error:e?.message||"Verification failed"},{status:400});}
}
