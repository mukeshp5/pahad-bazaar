import { NextResponse } from "next/server";
import Razorpay from "razorpay";
import { z } from "zod";
import { currentUser } from "@/lib/auth";
import { adminDb } from "@/lib/supabase/admin";

const schema=z.object({items:z.array(z.object({productId:z.string().uuid(),quantity:z.number().int().min(1).max(20)})).min(1).max(30)});
export async function POST(req:Request){
 try{
  const {user}=await currentUser();if(!user)return NextResponse.json({error:"Please sign in before checkout"},{status:401});
  const body=schema.parse(await req.json());
  const ids=body.items.map(i=>i.productId);
  const {data:products,error}=await adminDb.from("products").select("id,name,price_paise,stock_quantity,status,seller_id").in("id",ids);
  if(error||!products||products.length!==ids.length)return NextResponse.json({error:"One or more products are unavailable"},{status:400});
  let subtotal=0;const lines:any[]=[];
  for(const item of body.items){const p=products.find(x=>x.id===item.productId);if(!p||p.status!=="active"||p.stock_quantity<item.quantity)return NextResponse.json({error:`Insufficient stock for ${p?.name||"product"}`},{status:400});subtotal+=p.price_paise*item.quantity;lines.push({product_id:p.id,seller_id:p.seller_id,product_name:p.name,unit_price_paise:p.price_paise,quantity:item.quantity,line_total_paise:p.price_paise*item.quantity});}
  const shipping=0; // Replace with a live courier quote before charging customers.
  const total=subtotal+shipping;
  const {data:order,error:orderError}=await adminDb.from("orders").insert({customer_id:user.id,status:"payment_pending",subtotal_paise:subtotal,shipping_paise:shipping,total_paise:total,currency:"INR"}).select("id,order_number").single();
  if(orderError||!order)return NextResponse.json({error:orderError?.message||"Could not create order"},{status:500});
  const {error:lineError}=await adminDb.from("order_items").insert(lines.map(l=>({...l,order_id:order.id})));
  if(lineError){await adminDb.from("orders").delete().eq("id",order.id);return NextResponse.json({error:"Could not save order items"},{status:500});}
  const razorpay=new Razorpay({key_id:process.env.RAZORPAY_KEY_ID!,key_secret:process.env.RAZORPAY_KEY_SECRET!});
  const rpOrder=await razorpay.orders.create({amount:total,currency:"INR",receipt:order.order_number,notes:{marketplace_order_id:order.id,customer_id:user.id}});
  await adminDb.from("orders").update({razorpay_order_id:rpOrder.id}).eq("id",order.id);
  return NextResponse.json({orderId:order.id,razorpayOrderId:rpOrder.id,amount:total,orderNumber:order.order_number});
 }catch(e:any){return NextResponse.json({error:e?.message||"Checkout error"},{status:400});}
}
