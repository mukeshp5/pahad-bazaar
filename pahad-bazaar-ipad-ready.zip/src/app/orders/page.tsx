import { createClient } from "@/lib/supabase/server";
import { redirect } from "next/navigation";

export default async function Orders(){
 const db=await createClient();const {data:{user}}=await db.auth.getUser();if(!user)redirect("/account");
 const {data}=await db.from("orders").select("id,order_number,status,total_paise,created_at,order_items(product_name,quantity,line_total_paise)").eq("customer_id",user.id).order("created_at",{ascending:false});
 return <main className="container" style={{padding:"42px 0"}}><h1 className="brand">Your orders</h1>{data?.length?data.map(o=><div className="card" key={o.id} style={{padding:18,marginBottom:12}}><strong>{o.order_number}</strong><span className="pill" style={{marginLeft:10}}>{o.status}</span><p>₹{(o.total_paise/100).toFixed(2)}</p>{o.order_items?.map((i:any)=><div key={i.product_name} className="muted">{i.product_name} × {i.quantity}</div>)}</div>):<p className="muted">No orders yet.</p>}</main>;
}
