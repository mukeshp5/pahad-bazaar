import { createClient } from "@/lib/supabase/server";
import { notFound } from "next/navigation";
import { AddToCart } from "@/components/AddToCart";
import { inr } from "@/lib/money";

export default async function ProductPage({params}:{params:{slug:string}}) {
  const supabase=await createClient();
  const {data:p}=await supabase.from("products").select("*,profiles!products_seller_id_fkey(display_name)").eq("slug",params.slug).eq("status","active").single();
  if(!p) notFound();
  return <main className="container" style={{padding:"42px 0",display:"grid",gridTemplateColumns:"1fr 1fr",gap:36}}>
    <img src={p.images?.[0] || "https://images.unsplash.com/photo-1542838132-92c53300491e?w=900"} alt={p.name} style={{width:"100%",borderRadius:20,objectFit:"cover",maxHeight:520}}/>
    <div><span className="pill">{p.category}</span><h1 className="brand" style={{fontSize:38}}>{p.name}</h1><h2 style={{fontSize:28}}>{inr(p.price_paise)}</h2><p className="muted">Made in {p.origin_village ? `${p.origin_village}, ` : ""}{p.origin_district || "Uttarakhand"}</p><p style={{lineHeight:1.8}}>{p.description}</p><p className="muted">Seller: {p.profiles?.display_name || "Verified local producer"}</p><p>{p.stock_quantity>0?`${p.stock_quantity} available`:"Currently unavailable"}</p><AddToCart productId={p.id} disabled={p.stock_quantity<1}/><p className="muted" style={{fontSize:12,marginTop:20}}>Delivery charges and estimated delivery date are shown at checkout.</p></div>
  </main>;
}
