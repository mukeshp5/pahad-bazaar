import { createClient } from "@/lib/supabase/server";
import { ProductCard } from "@/components/ProductCard";

export default async function Products({ searchParams }: {searchParams:{q?:string;category?:string}}) {
  const supabase = await createClient();
  let query = supabase.from("products").select("*").eq("status","active").order("created_at",{ascending:false});
  if(searchParams.category) query=query.eq("category",searchParams.category);
  if(searchParams.q) query=query.ilike("name",`%${searchParams.q}%`);
  const {data:products}=await query;
  return <main className="container" style={{padding:"42px 0"}}><h1 className="brand" style={{fontSize:36}}>All products</h1><form style={{display:"flex",gap:8,maxWidth:520,margin:"18px 0 28px"}}><input className="input" name="q" placeholder="Search products..." defaultValue={searchParams.q}/><button className="btn">Search</button></form>{products?.length?<div className="grid-products">{products.map(p=><ProductCard key={p.id} p={p}/>)}</div>:<p className="muted">No products found yet.</p>}</main>;
}
