"use client";
import { useState } from "react";
import { createClient } from "@/lib/supabase/client";

export default function Account() {
  const [email,setEmail]=useState("");const [password,setPassword]=useState("");const [name,setName]=useState("");const [mode,setMode]=useState<"login"|"signup">("login");const [message,setMessage]=useState("");
  async function submit(e:React.FormEvent){e.preventDefault();setMessage("");const db=createClient();
    if(mode==="signup"){const {error}=await db.auth.signUp({email,password,options:{data:{display_name:name}}});setMessage(error?.message||"Account created. Check your email to confirm your address.");}
    else {const {error}=await db.auth.signInWithPassword({email,password});if(error)setMessage(error.message);else window.location.href="/";}
  }
  return <main className="container" style={{padding:"45px 0",maxWidth:480}}><div className="card" style={{padding:26}}><h1 className="brand">{mode==="login"?"Welcome back":"Create your account"}</h1><form onSubmit={submit} style={{display:"grid",gap:13}}>{mode==="signup"&&<input className="input" placeholder="Full name" value={name} onChange={e=>setName(e.target.value)} required/>}<input className="input" type="email" placeholder="Email address" value={email} onChange={e=>setEmail(e.target.value)} required/><input className="input" type="password" placeholder="Password (min 8 characters)" value={password} onChange={e=>setPassword(e.target.value)} minLength={8} required/><button className="btn">{mode==="login"?"Sign in":"Create account"}</button></form>{message&&<p className="muted">{message}</p>}<button className="btn secondary" style={{marginTop:12,width:"100%"}} onClick={()=>setMode(mode==="login"?"signup":"login")}>{mode==="login"?"New here? Create an account":"Already registered? Sign in"}</button></div></main>;
}
