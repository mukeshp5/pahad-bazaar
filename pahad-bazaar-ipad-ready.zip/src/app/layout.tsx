import type { Metadata, Viewport } from "next";
import "./globals.css";
import { Header } from "@/components/Header";
import { ServiceWorker } from "@/components/ServiceWorker";

export const metadata: Metadata = {
  title: "Pahad Bazaar | Made in the Himalayas",
  description: "Discover authentic products made by people of Uttarakhand.",
  applicationName: "Pahad Bazaar",
  manifest: "/manifest.webmanifest",
  appleWebApp: { capable: true, title: "Pahad Bazaar", statusBarStyle: "default" }
};
export const viewport: Viewport = { themeColor: "#244b3b", width: "device-width", initialScale: 1 };

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return <html lang="en"><body><ServiceWorker/><Header />{children}<footer style={{background:"#203f33",color:"#f7f4ec",marginTop:64,padding:"32px 0"}}><div className="container"><div className="brand" style={{fontSize:25}}>Pahad Bazaar</div><p style={{opacity:.8}}>From our mountains, to your home.</p><small>Supporting makers, growers and artisans across Uttarakhand.</small><div style={{marginTop:18,opacity:.7,fontSize:12}}>© {new Date().getFullYear()} Pahad Bazaar. Marketplace concept.</div></div></footer></body></html>;
}
