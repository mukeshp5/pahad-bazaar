"use client";
import { useEffect,useState } from "react";
import Link from "next/link";
import { createClient } from "@/lib/supabase/client";
import { inr } from "@/lib/money";

export default function CartPage() {
  const [items,setItems]=useState<any[]>([]);
  const [loading,setLoading]=useState(true);
  const [error,setError]=useState("");
  useEffect(()=>{load();},[]);
  async function load(){
    const cart=JSON.parse(localStorage.getItem("pb_cart")||"[]");
    if(!cart.length){setItems([]);setLoading(false);return;}
    const db=createClient();
    const {data}=await db.from("products").select("id,name,slug,price_paise,images,stock_quantity,status").in("id",cart.map((x:any)=>x.productId));
    setItems((data||[]).map(p=>({...p,quantity:cart.find((x:any)=>x.productId===p.id)?.quantity||1})));
    setLoading(false);
  }
  async function checkout(){
    setError("");
    const db=createClient();
    const {data:{user}}=await db.auth.getUser();
    if(!user){window.location.href="/account?next=/cart";return;}
    const res=await fetch("/api/checkout/create-order",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({items:items.map(i=>({productId:i.id,quantity:i.quantity}))})});
    const json=await res.json();
    if(!res.ok){setError(json.error||"Could not start checkout");return;}
    const key=process.env.NEXT_PUBLIC_RAZORPAY_KEY_ID;
    if(!key){setError("Payment is not configured yet. Add the Razorpay public key to your deployment.");return;}
    const script=document.createElement("script");script.src="https://checkout.razorpay.com/v1/checkout.js";
    script.onload=()=>{
      // The server creates the Razorpay order and stores the pending marketplace order.
      const rzp=new (window as any).Razorpay({key,amount:json.amount,currency:"INR",name:"Pahad Bazaar",description:"Marketplace order",order_id:json.razorpayOrderId,handler:async(response:any)=>{
        const verify=await fetch("/api/checkout/verify",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({...response,orderId:json.orderId})});
        const v=await verify.json();
        if(verify.ok){localStorage.removeItem("pb_cart");window.location.href="/orders?success=1";}else setError(v.error||"Payment verification failed");
      },prefill:{},theme:{color:"#244b3b"}});
      rzp.open();
    };
    document.body.appendChild(script);
  }
  const total=items.reduce((s,i)=>s+i.price_paise*i.quantity,0);
  return <main className="container" style={{padding:"42px 0",maxWidth:760}}><h1 className="brand" style={{fontSize:36}}>Your cart</h1>{loading?<p>Loading...</p>:!items.length?<div className="card" style={{padding:24}}>Your cart is empty. <Link href="/products">Explore products →</Link></div>:<div className="card" style={{padding:20}}>{items.map(i=><div key={i.id} style={{display:"flex",justifyContent:"space-between",padding:"12px 0",borderBottom:"1px solid #eee"}}><div><strong>{i.name}</strong><div className="muted">Qty: {i.quantity}</div></div><strong>{inr(i.price_paise*i.quantity)}</strong></div>)}<h2 style={{textAlign:"right"}}>Subtotal: {inr(total)}</h2><p className="muted">Shipping and applicable taxes are calculated separately.</p>{error&&<p style={{color:"crimson"}}>{error}</p>}<button className="btn" style={{width:"100%"}} onClick={checkout}>Proceed to secure payment</button></div>}</main>;
}
