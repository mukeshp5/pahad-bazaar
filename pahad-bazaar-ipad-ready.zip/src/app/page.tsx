import Link from "next/link";
import { createClient } from "@/lib/supabase/server";
import { ProductCard } from "@/components/ProductCard";

export default async function Home() {
  const supabase = await createClient();
  const { data: products } = await supabase.from("products").select("id,name,slug,description,price_paise,images,category,origin_district,stock_quantity").eq("status","active").order("created_at",{ascending:false}).limit(12);
  return <main>
    <section style={{background:"linear-gradient(115deg,#1f4938,#416d52)",color:"white",padding:"66px 0 58px"}}>
      <div className="container" style={{display:"grid",gridTemplateColumns:"1.2fr .8fr",gap:30,alignItems:"center"}}>
        <div><span className="pill" style={{background:"#dfeadd"}}>Authentic Uttarakhand marketplace</span><h1 className="brand" style={{fontSize:"clamp(38px,6vw,64px)",lineHeight:1.06,margin:"20px 0"}}>Bring the<br/>Pahad home.</h1><p style={{fontSize:17,lineHeight:1.7,maxWidth:560,color:"#e5eee6"}}>Discover food, crafts, textiles and thoughtful products made by people of the Himalayas. Every purchase supports a local maker.</p><div style={{display:"flex",gap:12,flexWrap:"wrap",marginTop:24}}><a className="btn" style={{background:"#f1eadb",color:"#244b3b"}} href="#products">Explore products</a><Link className="btn outline" href="/seller">Become a seller</Link></div></div>
        <img src="https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?w=1000" alt="Himalayan mountains" style={{width:"100%",height:310,objectFit:"cover",borderRadius:24}}/>
      </div>
    </section>
    <section className="container" style={{paddingTop:44}}>
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"end",gap:16,marginBottom:20}}><div><span className="pill">Shop local, support local</span><h2 className="brand" style={{fontSize:32,margin:"10px 0 0"}} id="products">Discover the Pahad</h2><p className="muted">A curated selection from Uttarakhand's makers and growers.</p></div><Link href="/products" style={{fontWeight:700,color:"#315b45"}}>View all →</Link></div>
      {products?.length ? <div className="grid-products">{products.map(p=><ProductCard key={p.id} p={p}/>)}</div> : <div className="card" style={{padding:28,textAlign:"center"}}><h3>Our first products are coming soon</h3><p className="muted">Seller onboarding is open. Register to list your products.</p><Link className="btn" href="/seller">Become a seller</Link><p className="muted" style={{fontSize:12}}>Run the SQL seed script to load demo products.</p></div>}
    </section>
    <section className="container" style={{padding:"48px 0 10px"}}><div className="card" style={{padding:28,background:"#f0f3eb",display:"flex",justifyContent:"space-between",alignItems:"center",gap:24,flexWrap:"wrap"}}><div><h2 className="brand" style={{fontSize:28,margin:"0 0 8px"}}>Are you a maker in Uttarakhand?</h2><p className="muted" style={{margin:0}}>List your products and reach customers across India.</p></div><Link className="btn" href="/seller">Start selling</Link></div></section>
  </main>;
}
