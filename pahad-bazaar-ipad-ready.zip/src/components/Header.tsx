import Link from "next/link";
import { ShoppingBag, Store, LayoutDashboard } from "lucide-react";

export function Header() {
  return <header style={{background:"white",borderBottom:"1px solid #e8e8e1",position:"sticky",top:0,zIndex:20}}>
    <div className="container" style={{height:72,display:"flex",alignItems:"center",justifyContent:"space-between",gap:16}}>
      <Link href="/" className="brand" style={{fontSize:25,color:"#244b3b",fontWeight:700}}>🏔 Pahad Bazaar</Link>
      <nav style={{display:"flex",alignItems:"center",gap:16,fontSize:14,fontWeight:600}}>
        <Link href="/#products">Shop</Link><Link href="/seller">Sell with us</Link><Link href="/account">Account</Link>
        <Link href="/admin" aria-label="Admin"><LayoutDashboard size={19}/></Link>
        <Link href="/cart" className="btn" style={{padding:"9px 12px"}}><ShoppingBag size={17}/> Cart</Link>
      </nav>
    </div>
  </header>;
}
