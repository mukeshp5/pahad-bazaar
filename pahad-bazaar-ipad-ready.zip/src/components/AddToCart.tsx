"use client";
import { useState } from "react";

export function AddToCart({ productId, disabled=false }: { productId:string; disabled?:boolean }) {
  const [added,setAdded] = useState(false);
  function add() {
    const old = JSON.parse(localStorage.getItem("pb_cart") || "[]");
    const found = old.find((x:any)=>x.productId===productId);
    if(found) found.quantity += 1; else old.push({productId,quantity:1});
    localStorage.setItem("pb_cart",JSON.stringify(old));
    setAdded(true);
    window.dispatchEvent(new Event("pb-cart"));
  }
  return <button className="btn" disabled={disabled} onClick={add}>{added ? "Added ✓" : "Add to cart"}</button>;
}
