import Link from "next/link";
import { AddToCart } from "./AddToCart";
import { inr } from "@/lib/money";

export function ProductCard({ p }: { p:any }) {
  const image = p.images?.[0] || "https://images.unsplash.com/photo-1542838132-92c53300491e?w=700";
  return <article className="card">
    <Link href={`/products/${p.slug}`}><img src={image} alt={p.name} style={{width:"100%",height:190,objectFit:"cover"}}/>
      <div style={{padding:"14px 14px 5px"}}><span className="pill">{p.category}</span><h3 style={{margin:"10px 0 4px",fontSize:17}}>{p.name}</h3><p className="muted" style={{fontSize:12,margin:0}}>Made in {p.origin_district || "Uttarakhand"}</p><strong style={{display:"block",marginTop:10,fontSize:18}}>{inr(p.price_paise)}</strong></div></Link>
    <div style={{padding:"10px 14px 14px"}}><AddToCart productId={p.id} disabled={p.stock_quantity<1}/></div>
  </article>;
}
